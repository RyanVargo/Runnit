package com.ryan.vargo.runnit;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class GuestScreen extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest_screen);
        this.getSupportActionBar().hide();

        final Button paceButton = findViewById(R.id.paceButton);
        final Button predictorButton = findViewById(R.id.predictorButton);

        //opens the pace calculator screen
        paceButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openSplitScreen();
            }
        });

        predictorButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                openPredictorScreen();
            }
        });

    }


    public void openSplitScreen()
    {
        Intent intent = new Intent(GuestScreen.this, PaceCalcScreen.class);
        startActivity(intent);
    }

    public void openPredictorScreen()
    {
        Intent intent = new Intent(GuestScreen.this, PredictorScreen.class);
        startActivity(intent);
    }
}
